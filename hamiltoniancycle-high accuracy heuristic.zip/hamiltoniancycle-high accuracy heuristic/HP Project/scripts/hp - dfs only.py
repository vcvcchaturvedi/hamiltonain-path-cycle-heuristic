#I have used threads in this program. If the problem set has more number of edges, kindly do not use threads as this will result in out of memory exception. In that case, invoke the function func2 each time for all edges.
from collections import defaultdict
import datetime
import copy
import threading
import sys
sys.setrecursionlimit(5000)
t1=datetime.datetime.now().time()
print ("Start time=",t1)
finalpath=[]
finalpaths=[[]]
del finalpaths[:]
fedges=[[]]
del fedges[:]
n=0
m=0
edges=[[]]
gotit=0
maxpathlength=0
graph = {}
def func(l):
    global graph,n,gotit,maxpathlength
    
    l2=graph[l[len(l)-1]]
    for i in range(0,len(l2)):
        l1=l[:]
        if l2[i] not in l:
            l1.append(l2[i])
            if len(l1)>maxpathlength:
                maxpathlength=len(l1)
                print(maxpathlength)
            if len(l1)==n:
                print("Found!")
                print(l1)
                gotit=True
                return
            if not gotit:
                func(l1)
                
def main2():
    global n,m,edges,gotit,maxpathlength,graph
    
    del edges[:]
    f=open("C./graph13.hcp","r")         #change to any of FHCP challenge set question file here
    if f.mode=='r':
        print("Reading file...")
        f1=f.readlines()
        i1=0
        for x in f1:
            i1=i1+1
            if i1<7:
                continue
            else:
                y=x.split(" ")
                #print(y)
                z1=-1
                z2=-1
                for i in range(0,len(y)):
                    try:
                        h=(int)(y[i])
                        if z1==-1:
                            z1=h
                        else:
                            z2=h
                            temp=[z1,z2]
                            edges.append(temp)
                            if(z1>n):
                                n=z1
                            if(z2>n):
                                n=z2
                            m=m+1
                    except:
                        continue
    f.close()
    edges2=[[]]
    del edges2[:]
    ed=[]
    del ed[:]
    print("m=",m)
    for i in range(0,m):
        if i not in ed:
            for j in range(i+1,m):
                if edges[i][0]==edges[j][1] and edges[i][1]==edges[j][0] or edges[i][0]==edges[j][0] and edges[i][1]==edges[j][1]:
                    ed.append(j)
            edges2.append(edges[i])             
    edges=copy.deepcopy(edges2)
    m=len(edges)
    for i in range(1,n+1):
        list1=[]
        del list1[:]
        for j in range(0,m):
            if edges[j][0]==i or edges[j][1]==i:
                if edges[j][0]==i:
                    list1.append(edges[j][1])
                else:
                    list1.append(edges[j][0])
        graph[i]=list1
    #print(graph)
    print("m=",m,"n=",n)
   
    #for i in range(0,len(graph[1])):
##    edges2=[[]]
##    del edges2[:]
##    for j in range(1,m):
##       edges2.append(edges[j])
##    func2(edges2,edges[0][0],edges[0][1],None,0)
    #for i1 in range(0,len(graph[1])):
    func([1])
    print("End time=",t2)
if __name__== "__main__":
    main2()
