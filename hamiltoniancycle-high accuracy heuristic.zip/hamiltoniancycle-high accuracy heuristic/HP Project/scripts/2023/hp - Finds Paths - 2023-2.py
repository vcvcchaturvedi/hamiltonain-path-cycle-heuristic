# I have used threads in this program. If the problem set has more number of edges, kindly do not use threads as this will result in out of memory exception. In that case, invoke the function func2 each time for all edges.
from collections import defaultdict
import threading
import datetime
import copy
import threading
import sys

sys.setrecursionlimit(5000)
t1 = datetime.datetime.now().time()
print("Start time=", t1)
finalpath = []
finalpaths = [[]]
del finalpaths[:]
fedges = [[]]
del fedges[:]
n = 0
m = 0
edges = [[]]
gotit = 0
maxpathlength = 0

paths = {}

allpaths = [[]]
del allpaths[:]
liste = [[]]
threads = []
del threads[:]
finaledges = [[]]
del threads[:]
del liste[:]
dfs = []
del dfs[:]
currents = []
del currents[:]


def DFS(G, v, seen=None, path=None):
    if seen is None:
        seen = []
    if path is None:
        path = [v]

    seen.append(v)

    paths = []
    for t in G[v]:
        if t not in seen:
            t_path = path[:] + [t]
            paths.append(tuple(t_path))
            paths.extend(DFS(G, t, seen[:], t_path))
    return paths


class Graph:
    # Constructor
    def __init__(self, vertices):
        self.V = vertices
        # default dictionary to store graph
        self.graph = defaultdict(list)

    def printAllPathsUtil(self, u, d, visited, path):
        global allpaths, gotit
        # Mark the current node as visited and store in path
        visited[u - 1] = True
        path.append(u)

        # If current vertex is same as destination, then print
        # current path[]
        if u == d:
            allpaths.append(path)
            if len(path) == self.V:
                print("GOT Hamiltonian path=", path)
                gotit = 1
        else:
            # If current vertex is not destination
            # Recur for all the vertices adjacent to this vertex
            for i in range(0, len(self.graph[u])):
                if visited[self.graph[u][i] - 1] == False:
                    self.printAllPathsUtil(self.graph[u][i], d, visited, path)

        # Remove current vertex from path[] and mark it as unvisited
        path.pop()
        visited[u - 1] = False

    # Prints all paths from 's' to 'd'
    def printAllPaths(self, s, d):
        # Mark all the vertices as not visited
        visited = [False] * (self.V)

        # Create an array to store paths
        path = []

        # Call the recursive helper function to print all paths
        self.printAllPathsUtil(s, d, visited, path)

    # function to add an edge to graph
    def addEdge(self, u, v):
        self.graph[u].append(v)
        self.graph[v].append(u)

    def DFSUtil(self, v, visited):
        global dfs
        # Mark the current node as visited and print it
        visited[v - 1] = True
        dfs.append(v)
        # Recur for all the vertices adjacent to this vertex
        for i in range(0, len(self.graph[v])):
            if visited[self.graph[v][i] - 1] == False:
                self.DFSUtil(self.graph[v][i], visited)

    # The function to do DFS traversal. It uses
    # recursive DFSUtil()
    def DFS(self, v):
        # Mark all the vertices as not visited
        visited = [False] * (len(self.graph))

        # Call the recursive helper function to print
        # DFS traversal
        self.DFSUtil(v, visited)


class myThread(threading.Thread):
    def __init__(
        self,
        threadID,
        name,
        edges2,
        source,
        destination,
        patho,
        currento,
        listpaths,
        count,
        currentold,
    ):
        threading.Thread.__init__(self)
        self.threadID = threadID
        self.name = name
        self.edges2 = edges2
        self.source = source
        self.destination = destination
        self.patho = patho
        self.currento = currento
        self.listpaths = listpaths
        self.count = count
        self.currentold = currentold

    def run(self):
        print("Starting " + self.name)
        # print_time(self.name, self.counter, 5)
        # print ("Exiting " + self.name)
        func2(
            self.edges2,
            self.source,
            self.destination,
            self.patho,
            self.currento,
            self.listpaths,
            self.count,
            self.currentold,
        )


def bfs_paths(graph, start, goal):
    queue = [(start, [start])]
    while queue:
        (vertex, path) = queue.pop(0)
        for next in graph[vertex] - set(path):
            if next == goal:
                yield path + [next]
            else:
                queue.append((next, path + [next]))


def shortest_path(graph, start, goal):
    l1 = iter((bfs_paths(graph, start, goal)))
    try:
        l = next(l1)
    except StopIteration:
        return None
    return l


def shortest_path2(graph, start, goal):
    list1 = []
    del list1[:]
    num = 0
    l1 = iter((bfs_paths(graph, start, goal)))
    try:
        l = next(l1)
    except StopIteration:
        return None
    if len(l) > 0:
        num = len(l)
    list1.append(l)
    while 1:
        try:
            l = next(l1)
            if not (l == None):
                if len(l) == num:
                    list1.append(l)
                elif len(l) < num:
                    del list1[:]
                    num = len(l)
                    list1.append(l)
                    print("hi")
                # print(l)
                else:
                    return list1
        except StopIteration:
            return list1


paths = [[]]
del paths[:]


def func2(
    edges2, source, destination, patho, currento, listpaths, count, currentold, in1
):
    global n, m, edges, graph, gotit, finalpath, maxpathlength, finaledges, finalpaths, fedges, threads, paths

    origsource = source
    origdestination = destination
    path2 = []
    del path2[:]
    path3 = []
    del path3[:]
    path = [[]]
    del path[:]
    listpath = [[]]
    del listpath[:]
    # if path4==None:
    if patho == None:
        graph2 = {}
        for i in range(1, n + 1):
            list1 = []
            del list1[:]
            for j in range(0, len(edges2)):
                if edges2[j][0] == i or edges2[j][1] == i:
                    if edges2[j][0] == i:
                        list1.append(edges2[j][1])
                    else:
                        list1.append(edges2[j][0])
            graph2[i] = set(list1)
        listpath = shortest_path2(graph2, source, destination)
        # print(listpath)
        if listpath != None:
            if len(listpath) == 0:
                return
            for i in range(0, len(listpath)):
                if len(listpath) == n:
                    gotit = 1
                    finalpath = listpath[i]
                    return

            for i in range(0, len(listpath)):
                path2 = listpath[i]
                current = 0
                random2 = len(path2)
                ##                if len(paths)==0:
                ##                   paths[len(path2)]=[[]]
                ##                   del paths[len(path2)][:]
                ##                   paths[len(path2)].append(path2)
                ##                   func2(edges2,source,destination,path2,current)
                ##                elif len(path2) not in paths:
                ##                       paths[len(path2)]=[[]]
                ##                       del paths[len(path2)][:]
                ##                       paths[len(path2)].append(path2)
                ##                       func2(edges2,source,destination,path2,current)
                ##                elif gotit==0 and path2 not in paths[len(path2)]:
                ##                    if len(paths[len(path2)])==0:
                ##                       paths[len(path2)]=[[]]
                ##                       del paths[len(path2)][:]
                ##                       paths[len(path2)].append(path2)
                ##                    else:
                ##                       paths[len(path2)].append(path2)
                edges5 = [[]]
                del edges5[:]

                ##                flag2=0
                ##                while(flag2==0 and current<random2-1):
                ##                    from1=path2[current];
                ##                    to1=path2[current+1];
                ##                    countfrom=0
                ##                    countto=0
                ##                    for g in range(0,len(edges2)):
                ##                        if(edges2[g][0]==from1 or edges2[g][1]==from1):
                ##                            countfrom+=1
                ##                        if(edges2[g][0]==to1 or edges2[g][1]==to1):
                ##                            countto+=1
                ##
                ##                    if((countto<3 and to1!=destination) or (countfrom<3 and from1!=source)):
                ##                        flag2=0
                ##                        current+=1
                ##                    else:
                ##                        flag2=1
                ##
                ##
                ##
                ##                if(current>=random2-1):
                ##                    continue
                ##                for k in range(0,len(edges2)):
                ##                   toadd=1
                ##                   for j in range(0,len(listpath)):
                ##                      if j!=i:
                ##                         if (edges2[k][0]==listpath[j][0] and edges2[k][1]==listpath[j][0+1]) or (edges2[k][1]==listpath[j][0] and edges2[k][0]==listpath[j][0+1]):
                ##                             toadd=0
                ##                             break
                ##                   if toadd==1:
                ##                       edges5.append(edges2[k])
                edges5 = edges2

                if gotit == 0:
                    ##                    paths.append(path2)
                    ##                    currents.append(0)
                    func2(
                        edges5,
                        source,
                        destination,
                        path2,
                        0,
                        listpath,
                        i,
                        current,
                        in1 + 1,
                    )
                else:
                    return
        # func2(edges2,0,1,path3)
        # return
    ##    else:
    ##        path2=path4
    ##        #print("Path2=",path2)
    ##        current=source
    ##    if(current>=len(path2)-1):
    ##        return
    ##    source=path2[current]
    ##    destination=path2[current+1]
    ##    random2=len(path2)
    else:
        current = currento

        path2 = patho
        random2 = len(path2)

        index = currento
        if not gotit and path2 != None:
            while index < random2 - 1 and gotit == 0:
                edges4 = [[]]
                del edges4[:]

                flag2 = 0
                while flag2 == 0 and index < random2 - 1:
                    from1 = path2[index]
                    to1 = path2[index + 1]
                    countfrom = 0
                    countto = 0
                    for g in range(0, len(edges2)):
                        if edges2[g][0] == from1 or edges2[g][1] == from1:
                            countfrom += 1
                        if edges2[g][0] == to1 or edges2[g][1] == to1:
                            countto += 1

                    if (
                        (countto < 3 and (to1 != destination and to1 != source))
                        or (
                            countfrom < 3 and (from1 != source and from1 != destination)
                        )
                        or (countto < 2 and (to1 == destination or to1 == source))
                        or (countfrom < 2 and (from1 == destination or from1 == source))
                    ):
                        # if(countto<2 or countfrom<2):

                        # flag2=0
                        index += 1
                    else:
                        flag2 = 1
                    if index >= random2 - 1:
                        break
                if index >= random2 - 1:
                    break

                current = index
                for i in range(0, len(edges2)):
                    toadd = 1
                    if (
                        edges2[i][0] == path2[current]
                        and edges2[i][1] == path2[current + 1]
                    ) or (
                        edges2[i][1] == path2[current]
                        and edges2[i][0] == path2[current + 1]
                    ):
                        toadd = 0

                    ##                    if current==currentold:
                    ##                       for j in range(0,len(listpaths)):
                    ##                         if j!=count:
                    ##                            if (edges2[i][0]==listpaths[j][currentold] and edges2[i][1]==listpaths[j][currentold+1]) or (edges2[i][1]==listpaths[j][currentold] and edges2[i][0]==listpaths[j][currentold+1]):
                    ##                                toadd=0
                    ##                                break
                    ##
                    ##                         if toadd==1:
                    ##                            for j in range(0,len(path2)):
                    ##                               if((edges2[i][0]==path2[j] or edges2[i][1]==path2[j]) and not(j==current or j==current+1)):
                    ##                                   toadd=0
                    if toadd == 1:
                        edges4.append([edges2[i][0], edges2[i][1]])
                ##                mainflag=1
                ##                for n1 in range(1,n+1):
                ##                   if n1!=source and n1!=destination:
                ##                     count=0
                ##                     for g in range(0,len(edges4)):
                ##                        if n1 in edges4[g]:
                ##                           count+=1
                ##                     if count<2:
                ##                        current+=1
                ##                        todo=1
                ##                        mainflag=0
                ##                        break
                ##                if mainflag==0:
                ##                   continue
                ##                flagt=1
                ##                for g in range(1,n+1):
                ##                   if g!=source and g!=destination:
                ##                      count=0
                ##                      for f in range(0,len(edges4)):
                ##                         if g in edges4[f]:
                ##                            count+=1
                ##                      if count<2:
                ##                        flagt=0
                ##                        break
                ##                if flagt==0:
                ##                   #print("Missing=",g,"in ",edges4)
                ##                   current+=1
                ##                   todo=1
                ##                   continue

                ##                flag2=0
                ##                while(flag2==0 and current<random2-1):
                ##                    from1=path2[current];
                ##                    to1=path2[current+1];
                ##                    countfrom=0
                ##                    countto=0
                ##                    for g in range(0,len(edges4)):
                ##                        if(edges4[g][0]==from1 or edges4[g][1]==from1):
                ##                            countfrom+=1
                ##                        if(edges4[g][0]==to1 or edges4[g][1]==to1):
                ##                            countto+=1
                ##
                ##                    if(countto<2 or countfrom<2 and (from1!=source and from1!=destination and to1!=source and to1!=destination)):
                ##                        flag2=0
                ##                        current+=1
                ##                    else:
                ##                        flag2=1
                ##
                ##
                ##
                ##                if(current>=random2-1):
                ##                    break

                graph2 = {}
                for i in range(1, n + 1):
                    list1 = []
                    del list1[:]
                    for j in range(0, len(edges4)):
                        if edges4[j][0] == i or edges4[j][1] == i:
                            if edges4[j][0] == i:
                                list1.append(edges4[j][1])
                            else:
                                list1.append(edges4[j][0])
                    graph2[i] = set(list1)
                listpath2 = shortest_path2(graph2, source, destination)
                if listpath2 == None:
                    # current=current+1
                    index += 1
                    continue
                else:
                    listpath = listpath2
                    fhflag = False
                    ##                    if len(listpath[0])==len(patho)+1:
                    for i in range(0, len(listpath)):
                        path1 = listpath[i]
                        x = path1[len(path1) - 2]

                        for j in range(i + 1, len(listpath)):
                            path2 = listpath[j]
                            y = path2[len(path2) - 2]
                            if y in graph2[x]:
                                fhflag = True
                                graph3 = {}
                                for i1 in range(1, n + 1):
                                    list1 = []
                                    del list1[:]
                                    for j1 in range(0, len(edges2)):
                                        if edges2[j1][0] == i1 or edges2[j1][1] == i1:
                                            if (
                                                x in edges2[j1]
                                                and destination in edges2[j1]
                                            ) or (
                                                y in edges2[j1]
                                                and destination in edges2[j1]
                                            ):
                                                continue
                                            if edges2[j1][0] == i:
                                                list1.append(edges2[j1][1])
                                            else:
                                                list1.append(edges2[j1][0])
                                    graph3[i1] = set(list1)
                                li1 = shortest_path(graph3, x, destination)
                                li2 = shortest_path(graph3, y, destination)
                                if li1 is not None and li2 is not None:
                                    if len(li1) <= len(li2):
                                        if len(li2) == n:
                                            print("GOTIT!")
                                            print(li2)
                                            gotit = True
                                            return
                                        num = path1[len(path1) - 3]
                                        graph3[num].remove(y)
                                        graph3[y].remove(num)
                                        edgesnew = []
                                        del edgesnew[:]
                                        for i1 in range(0, len(edges2)):
                                            a = edges2[i1][0]
                                            b = edges2[i1][1]
                                            if b in graph3[a]:
                                                edgesnew.append([a, b])
                                        func2(
                                            edgesnew,
                                            source,
                                            destination,
                                            path1,
                                            0,
                                            listpath,
                                            i,
                                            current,
                                            in1 + 1,
                                        )
                                        return
                                    else:
                                        if len(li1) == n:
                                            print("GOTIT!")
                                            print(li1)
                                            gotit = True
                                            return
                                        num = path2[len(path2) - 3]
                                        graph3[num].remove(x)
                                        graph3[x].remove(num)
                                        edgesnew = []
                                        del edgesnew[:]
                                        for i1 in range(0, len(edges2)):
                                            a = edges2[i1][0]
                                            b = edges2[i1][1]
                                            if b in graph3[a]:
                                                edgesnew.append([a, b])
                                        func2(
                                            edgesnew,
                                            source,
                                            destination,
                                            path2,
                                            0,
                                            listpath,
                                            i,
                                            current,
                                            in1 + 1,
                                        )
                                        return
                                elif li1 is not None:
                                    if len(li1) == n:
                                        print("GOTIT!")
                                        print(li1)
                                        gotit = True
                                        return
                                    edgesnew = []
                                    del edgesnew[:]
                                    for i1 in range(0, len(edges2)):
                                        a = edges2[i1][0]
                                        b = edges2[i1][1]
                                        if b in graph3[a]:
                                            edgesnew.append([a, b])
                                    func2(
                                        edgesnew,
                                        source,
                                        destination,
                                        path1,
                                        0,
                                        listpath,
                                        i,
                                        current,
                                        in1 + 1,
                                    )
                                    return
                                elif li2 is not None:
                                    if len(li2) == n:
                                        print("GOTIT!")
                                        print(li2)
                                        gotit = True
                                        return
                                    edgesnew = []
                                    del edgesnew[:]
                                    for i1 in range(0, len(edges2)):
                                        a = edges2[i1][0]
                                        b = edges2[i1][1]
                                        if b in graph3[a]:
                                            edgesnew.append([a, b])
                                    func2(
                                        edgesnew,
                                        source,
                                        destination,
                                        path2,
                                        0,
                                        listpath,
                                        i,
                                        current,
                                        in1 + 1,
                                    )
                                    return
                                else:
                                    return
                    ##                    for i in range(0,len(listpath2)):
                    if gotit == False:
                        path3 = listpath2[0]
                        ##                        path3=listpath2[i]
                        # mainpathlength=len(path2)+len(listpath2[i])-2;
                        if len(path3) == n:
                            del finalpath[:]
                            gotit = 1
                            # print("Path2=",path2)
                            # print("Path=",listpath2,source)

                            ##                            for z1 in range(0,current):
                            ##                                finalpath.append(path2[z1])
                            maxpathlength = n
                            path3.append(source)
                            path3.reverse()
                            for z2 in range(0, len(path3)):
                                finalpath.append(path3[z2])
                            # finalpath.append(source)
                            ##                            for z2 in range(current+2,len(path2)):
                            ##                                finalpath.append(path2[z1]);
                            print("GOTIT!")
                            print("HC= ", finalpath)
                            for i1 in range(0, len(threads)):
                                threads[i1]._stop = True
                            return
                        ##                        elif len(listpath2[i])==n-1:
                        ##                           random2=len(listpath2[i])
                        ##                           if maxpathlength<random2:
                        ##                                maxpathlength=random2
                        ##                                #print(maxpathlength)
                        ##                           missingno=-1
                        ##                           for j in range(1,n+1):
                        ##                              if j not in listpath2[i]:
                        ##                                 missingno=j
                        ##                                 break
                        ##                           #print(edges4,missingno)
                        ##                           print(listpath2[i],"missingno=",missingno)
                        ##                           for j in range(0,len(graph[missingno])):
                        ##                              edges5=copy.deepcopy(edges4)
                        ##                              edges5.append([missingno,graph[missingno][j]])
                        ##                              flag=1
                        ##                              if len(path2) not in paths:
                        ##                                   flag=0
                        ##                                   paths[len(path2)]=[[]]
                        ##                                   del paths[len(path2)][:]
                        ##                              elif path2 not in paths[len(path2)]:
                        ##                                   flag=0
                        ##                              if flag==0:
                        ####                                  mainflag=1
                        ####                                  for n1 in range(1,n+1):
                        ####                                     if n1!=source and n1!=destination:
                        ####                                       count=0
                        ####                                       for g in range(0,len(edges4)):
                        ####                                          if n1 in edges4[g]:
                        ####                                             count+=1
                        ####                                       if count<2:
                        ####                                          current+=1
                        ####                                          todo=1
                        ####                                          mainflag=0
                        ####                                          break
                        ####                                  if mainflag==0:
                        ####                                     print("LOL")
                        ##                                  func2(edges5,source,destination,path2,0)
                        ##                           return
                        ##                              for k in range(0,len(graph[source])):
                        ##                                 l=graph[source][k]
                        ##                                 if missingno in graph[l] and l!=missingno:
                        ##                                    print("FOUND THE PATH!",listpath2[i],missingno,l)
                        ##                                    gotit=1
                        ##                                    return

                        else:  # TO CODE HERE
                            random3 = len(path3)
                            if maxpathlength < random3:
                                maxpathlength = random3
                                print(maxpathlength)
                                del finalpaths[:]
                                del fedges[:]
                                finalpaths.append(listpath2[0])
                                fedges.append((edges4[:]))
                            elif maxpathlength == random3:
                                finalpaths.append(listpath2[0])
                                fedges.append((edges4[:]))
                                print(maxpathlength)
                            # edges2=edges4

                            if gotit == 0:
                                ##                                print(path2)
                                ##                                input()
                                edges5 = [[]]
                                del edges5[:]
                                ##                                if(len(listpath2)>1):  #needs edit
                                ##
                                ####                                    for j in range(0,len(listpath2[0])):
                                ####                                        if listpath2[0][j]!=listpath2[1][j]:
                                ####                                            break
                                ####                                        else:
                                ####                                            in1+=1
                                ####                                    in2=0
                                ####                                    todo2=1
                                ####                                    while todo2==1:
                                ####
                                ####                                        curnt=listpath2[i][in2]
                                ####
                                ####                                        for k in range(0,len(listpath2)):
                                ####                                            if k!=i:
                                ####                                                curnt2=listpath2[k][in2]
                                ####                                                if curnt!=curnt2:
                                ####                                                   todo2=0
                                ####                                                   break
                                ####                                            if todo2==0:
                                ####                                                break
                                ####                                        if todo2==1:
                                ####                                            in2+=1
                                ####                                    in2-=1
                                ####                                    in2=current
                                ##                                    edges6=[[]]
                                ##                                    del edges6[:]
                                ##
                                ##                                    for j in range(0,len(listpath2)):
                                ##                                      if j!=i:
                                ##                                         for l in range(0,len(listpath2[i])):
                                ##                                             if(l<len(listpath2[j])):
                                ##                                                 if(listpath2[i][l]!=listpath2[j][l]):
                                ##                                                     edges6.append([listpath2[j][l-1],listpath2[j][l]])
                                ##                                                     break
                                ##                                    edges5=copy.deepcopy(edges4)
                                ##                                    lo=len(edges5)
                                ##                                    k=0
                                ##                                    while(k<lo):
                                ##                                       toadd=1
                                ##                                       for j in range(0,len(edges6)):
                                ##                                           if (edges5[k][0]==edges6[j][0] and edges5[k][1]==edges6[j][1]) or (edges5[k][0]==edges6[j][1] and edges5[k][1]==edges6[j][0]):
                                ##                                               from1=edges6[j][0]
                                ##                                               to1=edges6[j][1]
                                ##                                               countfrom=0
                                ##                                               countto=0
                                ##                                               for a in range(0,len(edges5)):
                                ##                                                   if(edges5[a][0]==from1 or edges5[a][1]==from1):
                                ##                                                       countfrom+=1
                                ##                                                   if(edges5[a][0]==to1 or edges5[a][1]==to1):
                                ##                                                       countto+=1
                                ##                                               if((countto<3 and (to1!=destination and to1!=source)) or (countfrom<3 and (from1!=source and from1!=destination)) or (countto<2 and (to1==destination or to1==source)) or (countfrom<2 and (from1==destination or from1==source))):
                                ##                                                   continue
                                ##                                               else:
                                ####                                                   toadd=0
                                ##                                                   del edges5[k]
                                ##                                                   k-=1
                                ##                                                   lo=len(edges5)
                                ##                                                   break
                                ##                                       k+=1
                                ####                                       if toadd==1:
                                ####                                           edges5.append(edges4[k])
                                ##                                else:
                                edges5 = edges4[:]
                                ##                               if currento==currentold:
                                ##                                currentold=current
                                ##                                for k in range(0,len(edges4)):
                                ##                                    toadd=1
                                ##                                    for j in range(0,len(listpath2)):
                                ##                                         if j!=i:
                                ##
                                ##                                             if (edges4[k][0]==listpath2[j][currentold] and edges4[k][1]==listpath2[j][currentold+1]) or (edges4[k][1]==listpath2[j][currentold] and edges4[k][0]==listpath2[j][currentold+1]):
                                ##                                                toadd=0
                                ##                                                break
                                ##                                    if toadd==1:
                                ##                                        edges5.append(edges4[k])
                                ##                               else:
                                # edges5=copy.deepcopy(edges4)
                                ##                                if path3 not in paths:
                                ##                                    paths.append(path3)
                                ##                                    currents.append(current)
                                # print(edges5)

                                # for j in range(currento,len(path2)-1):
                                # for im in range(current,len(path3)-1):
                                func2(
                                    edges5,
                                    source,
                                    destination,
                                    path3,
                                    current,
                                    listpath2,
                                    i,
                                    current,
                                    in1 + 1,
                                )
                                return
                            ##                                else:
                            ##                                    vcurrent=currents[paths[::-1].index(path3)]
                            ##                                    if current>vcurrent and vcurrent!=-1:
                            ##                                        paths.append(path3)
                            ##                                        currents.append(current)
                            ##                                        func2(edges5,source,destination,path3,current,listpath2,i,current)
                            ##                                    else:
                            ##                                        break
                            else:
                                return
    ##                            if(mainpathlength>maxpathlength):
    ##                                maxpathlength=mainpathlength
    ##                                print(maxpathlength)
    ##                            path3=[]
    ##                            del path3[:]
    ##                            for z1 in range(0,current):
    ##                                path3.append(path2[z1])
    ##
    ##                            for z2 in range(0,len(listpath2[i])):
    ##                                path3.append(listpath2[i][z2])
    ##
    ##                            for z2 in range(current+2,len(path2)):
    ##                                path3.append(path2[z2]);
    ##
    ##                            for z1 in range (current+1,random2-1):
    ##                                if(not gotit):
    ##                                    if z1<random2-1:
    ##                                        func2(edges2,z1,z1+1,path3)
    # index+=1
    # print("index=",index,"and random2=",random2)


##                    break

##    if not(gotit):
##        source=origsource+1
##        destination=origdestination+1
##        if source<(len(path4)-1):
##            func2(edges2,source,destination,path4)


def main2():
    global n, m, edges, gotit, allpaths, finalpaths, fedges, finalpath, maxpathlength, liste, paths, threads, dfs
    graph = {}
    del edges[:]
    f = open(
        "./graph121.hcp", "r"
    )  # change to any of FHCP challenge set question file here
    if f.mode == "r":
        print("Reading file...")
        f1 = f.readlines()
        i1 = 0
        for x in f1:
            i1 = i1 + 1
            if i1 < 7:
                continue
            else:
                y = x.split(" ")
                # print(y)
                z1 = -1
                z2 = -1
                for i in range(0, len(y)):
                    try:
                        h = (int)(y[i])
                        if z1 == -1:
                            z1 = h
                        else:
                            z2 = h
                            temp = [z1, z2]
                            edges.append(temp)
                            if z1 > n:
                                n = z1
                            if z2 > n:
                                n = z2
                            m = m + 1
                    except:
                        continue
    f.close()
    edges2 = [[]]
    del edges2[:]
    ed = []
    del ed[:]
    print("m=", m)
    for i in range(0, m):
        if i not in ed:
            for j in range(i + 1, m):
                if (
                    edges[i][0] == edges[j][1]
                    and edges[i][1] == edges[j][0]
                    or edges[i][0] == edges[j][0]
                    and edges[i][1] == edges[j][1]
                ):
                    ed.append(j)
            edges2.append(edges[i])
    edges = edges2[:]
    m = len(edges)
    for i in range(1, n + 1):
        list1 = []
        del list1[:]
        for j in range(0, m):
            if edges[j][0] == i or edges[j][1] == i:
                if edges[j][0] == i:
                    list1.append(edges[j][1])
                else:
                    list1.append(edges[j][0])
        graph[i] = list1
    # print(graph)
    print("m=", m, "n=", n)

    # for i in range(0,len(graph[1])):
    ##    edges2=[[]]
    ##    del edges2[:]
    ##    for j in range(1,m):
    ##       edges2.append(edges[j])
    ##    func2(edges2,edges[0][0],edges[0][1],None,0)
    # for i1 in range(0,len(graph[1])):
    for i1 in range(6, m):
        edges2 = [[]]
        del edges2[:]
        for j in range(0, m):
            if not j == i1:
                # if not (edges[j][0]==1 and edges[j][1]==graph[1][i1]) or (edges[j][1]==1 and edges[j][0]==graph[1][i1]):
                edges2.append(edges[j])
        if not gotit:
            print("for edge", (i1 + 1))
            maxpathlength = 0
            ##            del finalpaths[:]
            ##            del fedges[:]
            # print("for edge",1,graph[1][i])
            # thread1 = myThread(i1+1, "Thread-"+str(i1+1), edges2,1,graph[1][i1],None,0,None,None,None)
            # thread1 = myThread(i1+1, "Thread-"+str(i1+1), edges2,edges[i1][0],edges[i1][1],None,0,None,None,None)
            ##            del liste[:]
            ##            paths.clear()
            # func2 (edges2,1,graph[1][i1],None,0,None,None,None ) \
            t = threading.Thread(
                target=func2,
                args=(edges2, edges[i1][0], edges[i1][1], None, 0, None, None, None, 0),
            )
            t.start()
            t.join()
            # threads.append(thread1)

        ##            for i in range(0,len(fedges)):
        ##                finaledges=fedges[i]
        ##                g = Graph(n)
        ##                missingv=[]
        ##                del missingv[:]
        ##                for k in range(1,n+1):
        ##                   flag=0
        ##                   for j in range(0,len(finaledges)):
        ##                      if k in finaledges[j]:
        ##                         flag=1
        ##                         break
        ##                   if flag==0:
        ##                      missingv.append(k)
        ##                for k in range(0,len(missingv)):
        ##                   for j in range(0,m):
        ##                      if edges[j][0]==missingv[k] or edges[j][1]==missingv[k]:
        ##                         finaledges.append(edges[j])

        ##
        ##                for k in range(0,len(finaledges)):
        ##                   g.addEdge(finaledges[k][0], finaledges[k][1])
        ##                del dfs[:]
        ##                g.DFS(finalpaths[i][0])
        ##
        ##                if len(dfs)==n:
        ##                    #print("dfs=",dfs)
        ##                    #if dfs[len(dfs)-1] in graph[finalpaths[i][0]]:
        ##                    fvalid=1
        ##                    for p in range(0,len(dfs)-1):
        ##                        valid=0
        ##                        for q in range(0,len(edges)):
        ##                            if (edges[q][0]==dfs[p] and edges[q][1]==dfs[p+1]) or (edges[q][1]==dfs[p] and edges[q][0]==dfs[p+1]):
        ##                                valid=1
        ##                                break
        ##                        if valid==0:
        ##                            print("Did not find edge: ",dfs[p]," to ",dfs[p+1])
        ##                            fvalid=0
        ##                            break
        ##                    if fvalid==1:
        ##                        print("Found the Hamiltonian path: Length=",len(dfs),"Path=",dfs)
        ##                        gotit=1
        ##                        break
        ##                else:
        ##                    print("len(dfs)=",len(dfs))

        ## 2nd dfs method-efficient
        for i in range(0, len(fedges)):
            finaledges = fedges[i]
            j = 0
            x = len(finaledges)
            while j < x:
                k = j + 1
                while k < x:
                    if (
                        finaledges[j][0] in finaledges[k]
                        and finaledges[j][1] in finaledges[k]
                    ):
                        del finaledges[k]
                        k -= 1
                        x -= 1
                    k += 1
                j += 1
            if len(finaledges) <= n + 14:
                print("Doing dfs now...")
                g = Graph(n)
                G = defaultdict(list)
                for s, t in finaledges:
                    G[s].append(t)
                    G[t].append(s)
                all_paths = DFS(G, finalpaths[i][0])
                max_len = max(len(p) for p in all_paths)
                max_paths = [p for p in all_paths if len(p) == max_len]
                if max_len == n:
                    fvalid = 1
                    for j in range(0, len(max_paths)):
                        for p in range(0, len(max_paths[j]) - 1):
                            valid = 0
                            for q in range(0, len(edges)):
                                if (
                                    edges[q][0] == max_paths[j][p]
                                    and edges[q][1] == max_paths[j][p + 1]
                                ) or (
                                    edges[q][1] == max_paths[j][p]
                                    and edges[q][0] == max_paths[j][p + 1]
                                ):
                                    valid = 1
                                    break
                            if valid == 0:
                                print(
                                    "Did not find edge: ",
                                    max_paths[j][p],
                                    " to ",
                                    max_paths[j][p + 1],
                                )
                                fvalid = 0
                                break
                    if fvalid == 1:
                        print(
                            "Found the Hamiltonian path: Length=",
                            len(max_paths[j]),
                            "Path=",
                            max_paths[j],
                        )
                        gotit = 1
                        return
                ##                        if max_paths[j][len(max_paths[j])-1] in graph[max_paths[j][0]]:
                ##                            gotit=1
                ##                            print("Found HC-",max_pathhs[j])
                ##                            return
                else:
                    print("max length=", max_len)
    ##            else:
    ##                print("Length of finaledges=",len(finaledges),finaledges)
    ##                input()

    # func2(edges2,1,graph[1][i],None,0,None,None,None)
    # thread1 = myThread(1, "Thread-"+str(1), edges,9,61,None,0 )
    # threads.append(thread1)
    ##    for i in range(0,len(threads)):
    ##        threads[i].start()
    ##            ###threads[0].start()
    ##    for i in range(0,len(threads)):
    ##
    ##        if gotit==0:
    ##            #if not threads[i].isAlive():
    ##             threads[i].join()

    if gotit == 1:
        print("Hamiltonian cycle is:", finalpath)
        t2 = datetime.datetime.now().time()
    else:
        print("Did not find hc")

        ##            for k in range(0,len(graph[finalpaths[i][0]])):
        ##                g.printAllPaths(finalpaths[i][0],graph[finalpaths[i][0]][k])
        t2 = datetime.datetime.now().time()
    ##            for j in range(0,len(allpaths)):
    ##                if len(allpaths[j])==n:
    ##                    print("FINALLY!")
    ##                else:
    ##                    print(allpaths[j],"with length",len(allpaths[j]))
    # if gotit==0:
    # print("Max path length=",len(finalpaths[0])," and its cycle is :",finalpaths[0])
    print("End time=", t2)


if __name__ == "__main__":
    main2()
