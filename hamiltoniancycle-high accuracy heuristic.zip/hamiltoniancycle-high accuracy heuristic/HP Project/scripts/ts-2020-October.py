# I have used threads in this program. If the problem set has more number of edges, kindly do not use threads as this will result in out of memory exception. In that case, invoke the function func2 each time for all edges.
from collections import defaultdict
import datetime
import copy
import threading
import sys

sys.setrecursionlimit(5000)
t1 = datetime.datetime.now().time()
print("Start time=", t1)
gotit = False


finalpath = []
finalpaths = [[]]
del finalpaths[:]
fedges = [[]]
del fedges[:]
n = 0
m = 0
edges = [[]]
maxpathlength = 0

paths = {}

allpaths = [[]]
del allpaths[:]
liste = [[]]
threads = []
del threads[:]
finaledges = [[]]
del threads[:]
del liste[:]
dfs = []
del dfs[:]
currents = []
del currents[:]


def DFS(G, v, seen=None, path=None):
    if seen is None:
        seen = []
    if path is None:
        path = [v]

    seen.append(v)

    paths = []
    for t in G[v]:
        if t not in seen:
            t_path = path + [t]
            paths.append(tuple(t_path))
            paths.extend(DFS(G, t, seen[:], t_path))
    return paths


def bfs_paths(graph, start, goal):
    queue = [(start, [start])]
    while queue:
        (vertex, path) = queue.pop(0)
        for next in graph[vertex] - set(path):
            if next == goal:
                yield path + [next]
            else:
                queue.append((next, path + [next]))


def shortest_path(graph, start, goal):
    l1 = iter((bfs_paths(graph, start, goal)))
    try:
        l = next(l1)
    except StopIteration:
        return None
    return l


def shortest_path2(graph, start, goal):
    list1 = []
    del list1[:]
    num = 0
    l1 = iter((bfs_paths(graph, start, goal)))
    try:
        l = next(l1)
    except StopIteration:
        return None
    if len(l) > 0:
        num = len(l)
    list1.append(l)
    while 1:
        try:
            l = next(l1)
            if not (l == None):
                if len(l) == num:
                    list1.append(l)
                elif len(l) < num:
                    del list1[:]
                    num = len(l)
                    list1.append(l)
                    print("hi")
                # print(l)
                else:
                    return list1
        except StopIteration:
            return list1


paths = [[]]
del paths[:]


def verify(path, mainedges):
    for i in range(0, len(path) - 1):
        x = path[i]
        y = path[i + 1]
        if [x, y] in mainedges or [y, x] in mainedges:
            continue
        else:
            print("No such edge :" + str(x) + " to " + str(y))
            return
    print("Validated!")


def main2():
    global n, m, edges, gotit, allpaths, finalpaths, fedges, finalpath, maxpathlength, liste, paths, threads, dfs
    graph = {}
    del edges[:]
    f = open(
        "./graph19.hcp", "r"
    )  # change to any of FHCP challenge set question file here
    if f.mode == "r":
        print("Reading file...")
        f1 = f.readlines()
        i1 = 0
        for x in f1:
            i1 = i1 + 1
            if i1 < 7:
                continue
            else:
                y = x.split(" ")
                # print(y)
                z1 = -1
                z2 = -1
                for i in range(0, len(y)):
                    try:
                        h = (int)(y[i])
                        if z1 == -1:
                            z1 = h
                        else:
                            z2 = h
                            temp = [z1, z2]
                            edges.append(temp)
                            if z1 > n:
                                n = z1
                            if z2 > n:
                                n = z2
                            m = m + 1
                    except:
                        continue
    f.close()
    edges2 = [[]]
    del edges2[:]
    ed = []
    del ed[:]
    print("m=", m)
    for i in range(0, m):
        if i not in ed:
            for j in range(i + 1, m):
                if (
                    edges[i][0] == edges[j][1]
                    and edges[i][1] == edges[j][0]
                    or edges[i][0] == edges[j][0]
                    and edges[i][1] == edges[j][1]
                ):
                    ed.append(j)
            edges2.append(edges[i])
    edges = copy.deepcopy(edges2)
    mainedges = copy.deepcopy(edges)
    removed = []
    source = 0
    graph2 = {}
    for i in range(1, n + 1):
        list1 = []
        del list1[:]
        for j in range(0, len(edges)):
            if edges[j][0] == i or edges[j][1] == i:
                if edges[j][0] == i:
                    list1.append(edges[j][1])
                else:
                    list1.append(edges[j][0])
        graph2[i] = set(list1)
    mainmax = 0
    for k in range(1, n + 1):
        source = k
        if gotit:
            break
        for i1 in range(1, n + 1):
            if gotit:
                break
            index = 0
            if maxpathlength > mainmax:
                mainmax = maxpathlength
            maxpathlength = 0
            if i1 > k:  # in graph2[k]:
                destination = i1
                flag = True
                edges = copy.deepcopy(mainedges)
                recent = None
                print("for edge " + str(k) + " to " + str(i1))
                while flag and not gotit:
                    flag = False

                    if len(removed) > 0:
                        l1 = removed[len(removed) - 1]
                        if not (l1 in edges):
                            edges.append(l1)
                    if recent:
                        if not (recent in removed) and not (
                            recent.reverse() in removed
                        ):
                            removed.append(recent)
                    graph3 = {}
                    for i in range(1, n + 1):
                        list1 = []
                        del list1[:]
                        for j in range(0, len(edges)):
                            if edges[j][0] == i or edges[j][1] == i:
                                if edges[j][0] == i:
                                    list1.append(edges[j][1])
                                else:
                                    list1.append(edges[j][0])
                        graph3[i] = set(list1)
                    path = shortest_path(graph3, source, destination)
                    if path == None:
                        break
                    ##                        recent=None
                    ##                        index+=1
                    ##                        edges.append(removed[len(removed)-2])
                    ##                        flag=True
                    ##                        continue
                    if len(path) >= n - 1:
                        gotit = True

                        verify(path, mainedges)
                        print(path)
                        print("Found the HP")
                        break
                    if len(path) > 1:
                        while index < len(path) - 1:
                            from1 = path[index]
                            to1 = path[index + 1]

                            countfrom = len(graph3[path[index]])
                            countto = len(graph3[path[index + 1]])
                            if (
                                (countto < 3 and (to1 != destination and to1 != source))
                                or (
                                    countfrom < 3
                                    and (from1 != source and from1 != destination)
                                )
                                or (
                                    countto < 2
                                    and (to1 == destination or to1 == source)
                                )
                                or (
                                    countfrom < 2
                                    and (from1 == destination or from1 == source)
                                )
                            ):
                                index += 1
                                continue
                            else:
                                break
                        if index >= len(path) - 1:
                            break

                        x1 = path[index]
                        x2 = path[index + 1]
                        l = [x1, x2]

                        edges2 = []
                        for i in range(0, len(edges)):
                            if edges[i][0] in l and edges[i][1] in l:
                                continue
                            else:
                                edges2.append(edges[i][:])
                        ##                    print(len(edges),len(edges2))
                        ##                    input()
                        if not (l in removed) and not (l.reverse() in removed):
                            removed.append(l)
                        edges = edges2
                        graph4 = {}
                        for i in range(1, n + 1):
                            list1 = []
                            del list1[:]
                            for j in range(0, len(edges)):
                                if edges[j][0] == i or edges[j][1] == i:
                                    if edges[j][0] == i:
                                        list1.append(edges[j][1])
                                    else:
                                        list1.append(edges[j][0])
                            graph4[i] = set(list1)
                        path2 = shortest_path(graph4, source, destination)
                        if path2 == None:
                            index += 1
                            flag = True
                            edges.append(l)
                            continue
                        if len(path2) >= n - 1:
                            gotit = True

                            verify(path2, mainedges)
                            print(path2)
                            print("Found the HP")
                            break
                        if len(path2) > 1:
                            flag = True
                            index = 0

                            path = path2
                            index2 = 0
                            while index2 < len(path) - 1:
                                from1 = path[index2]
                                to1 = path[index2 + 1]
                                countfrom = len(graph4[path[index2]])
                                countto = len(graph4[path[index2 + 1]])

                                if (
                                    (
                                        countto < 3
                                        and (to1 != destination and to1 != source)
                                    )
                                    or (
                                        countfrom < 3
                                        and (from1 != source and from1 != destination)
                                    )
                                    or (
                                        countto < 2
                                        and (to1 == destination or to1 == source)
                                    )
                                    or (
                                        countfrom < 2
                                        and (from1 == destination or from1 == source)
                                    )
                                ):
                                    index2 += 1
                                    continue
                                else:
                                    break
                            if index2 >= len(path) - 1:
                                break
                            recent = [path[index2], path[index2 + 1]]
                            edges2 = []
                            for i in range(0, len(edges)):
                                if edges[i][0] in recent and edges[i][1] in recent:
                                    continue
                                else:
                                    edges2.append(edges[i][:])
                            ##                            if len(edges)==len(edges2):
                            ##                                break
                            edges = edges2

                        if len(path2) > maxpathlength:
                            maxpathlength = len(path2)
                            print(maxpathlength)

    t2 = datetime.datetime.now().time()

    print("End time=", t2, mainmax)


if __name__ == "__main__":
    main2()
