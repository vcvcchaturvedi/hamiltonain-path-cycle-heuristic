/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 *//*
 * @author Vinay Chaturvedi
 */


package hamiltoniancycle;




import java.util.Scanner;




 import java.io.*;
import java.util.*;
import javax.swing.JFileChooser;

public class MainJFrame extends javax.swing.JFrame {

   
    
public static int maxpathlength=0;   //to store the maximum path length of cycle attained by trimming algorithm
public static List finalpaths;       //List to store the max path cycles obtained by trimming algorithm for each invocation of trimming function 
public static List fedges=new ArrayList<int[][]>(); //List of arrays to store the corresponding edges at each instance when above max path cycle is found
public static List<Integer> dfs;                    //variable to store DFS
//    private void func2(int[][] edges2, int n, int m2, int source, int destination) {        //This is the trimming function and is invoked for each edge - using func3 instead!
//        int current=-1;                     //this is the 'current' variable of the algorithm
//         
//         int[] path2=null;                 //this stores the intermediate path array in iterations
//         
//       TestDijkstraAlgorithm tj=new TestDijkstraAlgorithm();    //This class is used to run a Dijkstra's run
//         LinkedList<Vertex> path=null;                          //this variable is used to store the output from above run
//          path=tj.testExcute(edges2,n,m2,source,destination);   //Dijkstra's run with input as current functions edges and targets as source and destination passed to this function(func2)
//                                                                //This is the initial run
//																
//          if(path!=null)                                    //That is a path is found
//          {
//          if(path.size()>=n)                        
//          {
//              gotit=true;                                   //Path of length n found so set final flag variable to true
//             answer=new int[n+1];                           //Next store the answer in answer variable and return
//                                    
//            int z1;
//            for(z1=0;z1<path.size();z1++)
//                answer[z1]=Integer.parseInt(path.get(z1).getId());  //Since path is list of 'Vertex' class objects, so need to convert to integer array
//            answer[z1]=source;
//
//            return;              //Answer found, return
//          }
//          current=0;   //Else set current to 0, which is start of path and continue                             
//         int h=0;       //Next copy path to path2 integer array
//                    path2=new int[path.size()];
//		for (Vertex vertex : path) {
//			
//                        path2[h]=Integer.valueOf(vertex.getName());
//                        h++;
//		}
//                 int random2;           //This is used to store current path's length      
//                random2=path2.length;   
//                if(maxpathlength<random2)      //That is maximum path length is less than current path length
//                    maxpathlength=random2;    //set maximum path length to current path length
//          if(!gotit && path!=null)          //That is Hamiltonian Cycle is not yet obtained and path!=null
//          {
//             
//              
//              
//            
//           
//              outer: do                             // Start of iterations...
//            {
//           
//                int i;
//                boolean todo=true;                 //flag variable used for iterations
//                 while(current<random2-1 && todo && !gotit)  //That is while 'current' and flag are valid
//               {
//                  
//                  todo=false;                              //set flag to false initially
//                  int[][] edges4=new int[m2-1][];          //This is the edges variable used to store one less edge than current edges array
//                  int q=0;          
//                   random2=path2.length;
//                  //Now we check if deleting path's [current -  current+1] edge will result in any vertex having degree equal to 0
//                  boolean flag2=false;                        
//                                while(!flag2 && current<random2-1 && !gotit)
//                                {
//                                    flag2=false;
//                                
//                                int from=path2[current];
//                                int to=path2[current+1];
//                                int countfrom=0,countto=0;
//                                for(int g=0;g<edges2.length;g++)
//                                {
//                                    if(edges2[g][0]==from || edges2[g][1]==from)
//                                        countfrom++;
//                                    if(edges2[g][0]==to || edges2[g][1]==to)
//                                        countto++;
//                                }
//                                if((countto<3 && destination!=to) || (countfrom<3 && source!=from) || (countfrom<2 && source==from) || (countto<2 && destination==to))               //That is total degree after deletion should be at least 1 and not 0
//                                {
//                                    flag2=false;
//                                    current++;
//                                }
//                                else
//                                    flag2=true;
//                                };
//                                if(current==random2-1)      //That is in the above process the whole of path has been utilised, then we need to break the iterations
//                                    break outer;
//                                
//                //Now set the new edges variable to one less than edges of the current iteration(break path from current to current+1 vertices
//                for(i=0;i<edges2.length;i++)
//                {
//                    
//                    if(!((edges2[i][0]==path2[current] && edges2[i][1]==path2[current+1]) || (edges2[i][1]==path2[current] && edges2[i][0]==path2[current+1])))
//                    {
//                        edges4[q]=new int[2];
//                        edges4[q][0]=edges2[i][0];
//                        edges4[q][1]=edges2[i][1];
//                        q++;
//                    }
//                    
//                }
//                
//                   
//                //Now run Dijkstra's algorithm between source and destination with new edges variable  
//                                TestDijkstraAlgorithm tj2=new TestDijkstraAlgorithm();
//                                
//                                
//                                path=tj2.testExcute(edges4,n,edges4.length,source,destination);        
//                           if(path!=null)   //That is a path exists
//                                {
////                                if(path.size()+1>=n)
////                                {
//                                    if(path.size()==n)         //That is we have found the Hamiltonian Cycle within the trimming function itself
//                                    {
//                                        //Set flag to true and write to answer variable the Hamiltonian Cycle's path
//                                    gotit=true;
//                                    answer=new int[n+1];
//                                    
//                                    int z1;
//                                    for(z1=0;z1<path.size();z1++)
//                                        answer[z1]=Integer.parseInt(path.get(z1).getId());
//                                    answer[z1]=source;
//                                    
//                                    break outer;    //break the iterations
//                                    }
//                                    
//                                else if(path.size()>0)      //else if path's size is less than n but greater than 0
//                                {
//                                   
//                                    random2=path.size();    //set path length to new path's size
//                                    if(maxpathlength<random2){  //that is if maximum path length has been attained
//                    maxpathlength=random2;          //set maximumpathlength variable to current path length
//                    System.out.println(maxpathlength);  //used for debugging-to better know how much of the processing has been done so far
//                    finalpaths=new ArrayList<int[]>();  //reinitialize the final paths storing list as we have got a better final path
//                    fedges=new ArrayList<int[][]>();    //reinitialize the final edges variable as well
//                    fedges.add(edges4);                 //add current edges to final edges
//                    //Now set a temppath integer array equal to path
//                    h=0;            
//                    int[] temppath=new int[path.size()];
//                    for (Vertex vertex : path) {
//			
//                        temppath[h]=Integer.valueOf(vertex.getName());
//                        h++;
//		}
//                            finalpaths.add(temppath);   //add temppath to finalpaths List
//                                    }
//                                    else if(maxpathlength==random2)   //That is if we have found another path that is candidate for adding to finalpaths and fedges Lists
//                                    {
//                                        //Initialize finalpaths and fedges if they are null
//                                        if(finalpaths==null)
//                                        {
//                                            finalpaths=new ArrayList<int[]>();
//                                        }
//                                        if(fedges==null)
//                                        {
//                                            fedges=new ArrayList<int[][]>();
//                                        }
//                                        fedges.add(edges4);   //add current edges to fedges List
//                    //Now set a temppath integer array equal to path
//                                        h=0;
//                    int[] temppath=new int[path.size()];
//                    for (Vertex vertex : path) {
//			
//                        temppath[h]=Integer.valueOf(vertex.getName());
//                        h++;
//		}
//                            finalpaths.add(temppath); //add temppath to finalpaths List
//                                    }
//                                    //Now proceed to set variables for next iteration:
//                                    m2=edges4.length;   //this variable m2 is updated to set the current edges length
//                                   
//                                    edges2=edges4;     //main edges variable is updated to be equal to current edges variable
//                                    
//                                   //Now set path2 variable to store contents of path array
//                                    h=0;
//                    path2=new int[path.size()];
//		for (Vertex vertex : path) {
//			
//                        path2[h]=Integer.valueOf(vertex.getName());
//                        h++;
//		}
//                                    
//                                        random2=path2.length; //Store the new path2 variable's length in random2
//
//                                    continue outer;   //Continue the iterations
//                                
//                                }
//                                }
//                                else{     //That is if no path is found we need to increment current and continue
//                               current++;
//                                
//                                todo=true;
//                                
//                                }
//                    
//                           
//               
//                           
//                       
//                   
//               }
//                
//                
//               
//               
//           
//               }while(current<random2-1);   //continue the iterations till current can account for path's length
//            
//     }
//    }
//    }
   static int lastpathCount=0;
   List<int[]> similarPaths = new ArrayList<int[]>();
   private List<List<Integer>> getBFSPaths(int[][] edges2,int n,int source,int destination) {
       List<List<Integer>> bfspaths=new ArrayList<List<Integer>>();
       List<List<Integer>> paths=new ArrayList<List<Integer>>();
       List<Integer> path=new ArrayList<Integer>();
       path.add(source);
       paths.add(path);
       boolean possible=true;
       int finall=0;
       do {
           possible=false;
           List<List<Integer>> newpaths=new ArrayList<List<Integer>>();
           List<Integer> lasts=new ArrayList<Integer>();
           for(int j=0;j<paths.size();j++){
               path=paths.get(j);
               int l=path.get(path.size()-1);
               for(int i=0;i<edges2.length;i++)
       {
                if((edges2[i][0]==l && !path.contains(edges2[i][1]) && !lasts.contains(edges2[i][1]))|| (edges2[i][1]==l && !path.contains(edges2[i][0]) && !lasts.contains(edges2[i][0])))
                {
                    possible=true;
                    List<Integer> newpath=new ArrayList<Integer>(path);
                    if(edges2[i][0]==l)
                    {
                        newpath.add(edges2[i][1]);
                        lasts.add(edges2[i][1]);
                    } else
                    {
                        newpath.add(edges2[i][0]);
                        lasts.add(edges2[i][0]);
                    }
                        if(newpath.get(newpath.size()-1)==destination) {
                            finall=newpath.size();
                            bfspaths.add(newpath);
                        }
//                        return newpath;
                    newpaths.add(newpath);
                }
       }
           }
           paths=newpaths;
           if(finall>0) return bfspaths;
       }while(possible);
       
       return bfspaths;
   }
   private void func3(int[][] edges2, int n, int m2, int source, int destination,int[] patho,int currento) { 
       
       int i,j,k,l;
       int current=-1;
       int[] path2=null; 
       List<Integer> path=null;
       List<List<Integer>> pathsbfs;
       if (patho==null)
       {
//           TestDijkstraAlgorithm tj1=new TestDijkstraAlgorithm();
//                                
//                                
//                               LinkedList<Vertex> pathr=tj1.testExcute(edges2,n,edges2.length,source,destination);  
////           List<List<Integer>> g=new ArrayList<List<Integer>>();
//           for(i=0;i<n;i++)
//           {
//               List<Integer> temp=new ArrayList<Integer>();
//               g.add(temp);
//           }
//           for(i=0;i<edges2.length;i++)
//           {
//               int from=edges2[i][0];
//               int to=edges2[i][1];
//               from--;
//               to--;
//               g.get(from).add(to);
//               g.get(to).add(from);
//           }
//           path=bfs(g,source-1,destination-1);
                               
                               
                               
//       Graph2 g1=new Graph2(n);
//       int i,j,k,l;
//       for(i=0;i<m2;i++)
//       {
//           g1.addEdge(edges2[i][0]-1, edges2[i][1]-1);
//       }
//       path=g1.findpath(source-1, destination-1);
       List<List<Integer>> pathr=getBFSPaths(edges2,n,source,destination);    
       if(pathr.size()>0)
       {
//           for(i=0;i<g1.bfspaths.size();i++)
//           {
//               path2=new int[path.size()];
//               for(j=0;j<path.size();j++)
//               {
//                   path2[j]=path.get(j);
//                   path2[j]++;
//                   
//               }
           for(int b=0;b<pathr.size();b++) {
              
              path2=new int[pathr.get(b).size()];
              for(int h=0;h<pathr.get(b).size();h++)
                  path2[h]=pathr.get(b).get(h);
                          
               current=0;
               List<int[]> al=new ArrayList<int[]>();
               for(j=0;j<edges2.length;j++)
               {
                    boolean toadd=true;
//                   for(k=0;k<g1.bfspaths.size();k++)
//                       if(k!=i)
//                       {
//                          
//                           if(edges2[j][0]==(g1.bfspaths.get(k).get(current)+1) && edges2[j][1]==(g1.bfspaths.get(k).get(current+1)+1) || edges2[j][1]==(g1.bfspaths.get(k).get(current)+1) && edges2[j][0]==(g1.bfspaths.get(k).get(current+1)+1) )
//                           {
//                               toadd=false;
//                               break;
//                           }
//                       }
//                   if(edges2[j][0]==path2[current] && edges2[j][1]==path2[current+1] || edges2[j][1]==path2[current] && edges2[j][0]==path2[current+1])
//                       toadd=false;
                   if(toadd)
                       al.add(edges2[j]);
               }
               int[][] edges3=new int[al.size()][];
               for(j=0;j<al.size();j++)
               {
                   edges3[j]=new int[2];
                   edges3[j][0]=al.get(j)[0];
                   edges3[j][1]=al.get(j)[1];
               }
               int m3=al.size();
//               System.out.print("For path");
//               for(int g=0;g<path2.length;g++)
//                   System.out.print(path2[g]+" ");
//               System.out.println();
               func3(edges3,n,m3,source,destination,path2,current);
//           }
       }
       }
       }
       else
       {
           path2=patho;
           current=currento;
           int random2=path2.length-1;
            
           
                
                boolean todo=true;                 //flag variable used for iterations
                 while(current<=random2-1 && todo && !gotit)  //That is while 'current' and flag are valid
               {
                  random2=path2.length-1;
                  todo=false;                              //set flag to false initially
                  List<int[]> al3=new ArrayList<int[]>();
                            //This is the edges variable used to store one less edge than current edges array
                  int q=0;          
                  
                  //Now we check if deleting path's [current -  current+1] edge will result in any vertex having degree equal to 0
                  boolean flag2=false;                        
                                while(!flag2 && current<=random2-1)
                                {
                                   
                                
                                int from=path2[current];
                                int to=path2[current+1];
                                int countfrom=0,countto=0;
                                for(int g=0;g<edges2.length;g++)
                                {
                                    if(edges2[g][0]==from || edges2[g][1]==from)
                                        countfrom++;
                                    if(edges2[g][0]==to || edges2[g][1]==to)
                                        countto++;
                                }
                               if((countto<3 && (to!=destination && to!=source)) || (countfrom<3 && (from!=source && from!=destination)) || (countto<2 && (to==destination || to==source)) || (countfrom<2 && (from==destination || from==source)))              //That is total degree after deletion should be at least 1 and not 0
                                {
                                    current++;
                                }
                                else
                                    flag2=true;
                               
                                }
                                if(current>=random2-1)      //That is in the above process the whole of path has been utilised, then we need to break the iterations
                                    return;
                                q=0;
                             //  System.out.println(edges2.length+"Current="+path2[current]+"Current+1="+path2[current+1]);
                //Now set the new edges variable to one less than edges of the current iteration(break path from current to current+1 vertices
                for(i=0;i<edges2.length;i++)
                {
                    
                    if(!((edges2[i][0]==path2[current] && edges2[i][1]==path2[current+1]) || (edges2[i][1]==path2[current] && edges2[i][0]==path2[current+1])))
                    {
                        al3.add(edges2[i]);
                    }
                   
                }
               //System.out.println("al3.size()="+al3.size());
                int[][] edges4=new int[al3.size()][];
                for(i=0;i<al3.size();i++)
                {
                    edges4[i]=new int[2];
                    edges4[i][0]=al3.get(i)[0];
                    edges4[i][1]=al3.get(i)[1];
                }
                   
                //Now run Dijkstra's algorithm between source and destination with new edges variable  
                
                
//                 TestDijkstraAlgorithm tj2=new TestDijkstraAlgorithm();
//                                
//                                
//                               LinkedList<Vertex> pathc=tj2.testExcute(edges4,n,edges4.length,source,destination);  
////                                     Graph2 g2=new Graph2(n);
//       
//       for(i=0;i<edges4.length;i++)
//       {
//           g2.addEdge(edges4[i][0]-1, edges4[i][1]-1);
//       }
//       path=g2.findpath(source-1, destination-1);
                               
                               
                               
                               
//       List<List<Integer>> g=new ArrayList<List<Integer>>();
//           for(i=0;i<n;i++)
//           {
//               List<Integer> temp=new ArrayList<Integer>();
//               g.add(temp);
//           }
//           for(i=0;i<edges4.length;i++)
//           {
//               int from=edges4[i][0];
//               int to=edges4[i][1];
//               from--;
//               to--;
//               g.get(from).add(to);
//               g.get(to).add(from);
//           }
//           path=bfs(g,source-1,destination-1);
                         List<List<Integer>> pathc=getBFSPaths(edges4,n,source,destination);
                           if(pathc.size()>0)   //That is a path exists
                                {
                               
                               if(pathc.size()>1) {
                               int currentb=current;
                               boolean flagb=true;
                               while(flagb && currentb<pathc.get(0).size()-2) {
                               int cu = pathc.get(0).get(currentb);
                               for(int b=1;b<pathc.size();b++) {
                                   if(pathc.get(b).get(currentb)!=cu) {
                                       flagb=false;
                                       break;
                                   }
                               }
                               
//                               if(current>pathc.get(0).size()-2) {
//                                   current--;
//                                   break;
//                               }
                                  
                               currentb++;
                               }
                               current=currentb-1>=0?currentb-1:currento;
                               }
                               int newcurrent=current;
                               for(int b=0;b<pathc.size();b++) {
//                                if(path.size()+1>=n)
//                                {
//                               for(int g=0;g<g2.bfspaths.size();g++)
//                               {
                                // System.out.println("startg="+g);
                                
                                  int[] path3=new int[pathc.get(b).size()];
                                   int h=0;
		for (int pp=0;pp<pathc.get(b).size();pp++) {
			
                        path3[h]=pathc.get(b).get(pp);
                        h++;
		}
                                   //System.out.print("hi "+i+" UO");
//               for(j=0;j<path.size();j++)
//               {
//                   path3[j]=path.get(j);
//                   path3[j]++;
//                   //System.out.print(" "+path2[j]);
//               }
               //System.out.println();
                                    if(path3.length==n)         //That is we have found the Hamiltonian Cycle within the trimming function itself
                                    {
                                        //Set flag to true and write to answer variable the Hamiltonian Cycle's path
                                    gotit=true;
                                    answer=new int[n+1];
                                    
                                    int z1;
                                    for(z1=0;z1<path3.length;z1++)
                                        answer[z1]=path3[z1];
                                    answer[z1]=source;
                                    
                                    break;    //break the iterations
                                    }
//                                    else if(path3.length<n+2) {
//                                      int[][] finaledges=edges4;
//                List<List<Integer>> G=new ArrayList<List<Integer>>();
//                for(int j1=0;j1<n;j1++)
//                {
//                    List<Integer> temp=new ArrayList<Integer>();
//                    G.add(temp);
//                }
//                for(int j1=0;j1<finaledges.length;j1++)
//                {
//                    int from=finaledges[j1][0];
//                    int to=finaledges[j1][1];
//                    from--;
//                    to--;
//                    G.get(from).add(to);
//                    G.get(to).add(from);
//                }
//                List<List<Integer>> dfspaths=dfs(G,source-1,null,null);
//                int max_len=0;
//                for(int j1=0;j1<dfspaths.size();j1++)
//                    if(dfspaths.get(j1).size()>max_len)
//                        max_len=dfspaths.get(j1).size();
//                if(max_len==n)
//                {
//                String str="";
//                answer=new int[n];
//                int p=0;
//                for(int j1=0;j1<dfspaths.size();j1++)
//                    if(dfspaths.get(j1).size()==max_len)
//                    {
////                        int y=dfspaths.get(j1).get(dfspaths.get(j1).size()-1);
////                        List<Integer> list=G.get(source-1);
////                        if(!list.contains(y))
////                            continue;
//                        for(int k1=0;k1<dfspaths.get(j1).size();k1++)
//                        {
//                            int num=dfspaths.get(j1).get(k1)+1;
//                            answer[p] = num;
//                            p++;
//                            str+=String.valueOf(num)+",";
//                        }
//                        gotit=true;
//                        return;
//                    }
//                
//                
//                }
//               
//                                    }
                                List<int[]> al = new ArrayList<int[]>();
                                int vt = path3[current];
                                List<int[]> indexes = new ArrayList<int[]>();
                                for(int a=0;a<pathc.size();a++) {
                                    if(a!=b) {
                                        List<Integer> pathh = pathc.get(a);
                                        for(int c=0;c<pathh.size()-1;c++) {
                                            if(pathh.get(c) == vt) {
                                                int[] d = new int[2];
                                                d[0]=vt;
                                                d[1]=pathh.get(c+1);
                                                indexes.add(d);
                                            }
                                        }
                                    }
                                }
                                for(int a=0;a<edges4.length;a++) {
                                    boolean toadd=true;
                                    if(edges4[a][0]==vt || edges4[a][1]==vt) {
                                        if(edges4[a][0]==vt) {
                                            for(int c=0;c<indexes.size();c++) {
                                                if(indexes.get(c)[1]==edges4[a][1]) {
                                                    toadd = false;
                                                    break;
                                                }
                                            }
                                        }
                                        else {
                                            for(int c=0;c<indexes.size();c++) {
                                                if(indexes.get(c)[1]==edges4[a][0]) {
                                                    toadd = false;
                                                    break;
                                                }
                                            }
                                        }
                                    }
                                    if(toadd) 
                                        al.add(edges4[a]);
                                }
                                int[][] edges5 = new int[al.size()][];
                                for(j=0;j<al.size();j++)
                                 {
                                 edges5[j]=new int[2];
                                 edges5[j][0]=al.get(j)[0];
                                 edges5[j][1]=al.get(j)[1];
                                }
                                if(path3.length>0)      //else if path's size is less than n but greater than 0
                                {
                                    
//                                    if(path3.length>lastpathCount){
//                                        if(similarPaths.size()>0){
//                                        int max=path2.length;
//                                        int pos=-1;
//                                        for(int o=0;o<similarPaths.size();o++)
//                                        {
//                                            int[][] edges5=new int[edges4.length+1][];
//                                            int v=0;
//                                            for(;v<edges4.length;v++){
//                                                edges5[v]=new int[2];
//                                                edges5[v][0]=edges4[v][0];
//                                                edges5[v][1]=edges4[v][1];
//                                            }
//                                            edges5[v]=similarPaths.get(o);
//                                            TestDijkstraAlgorithm tj3=new TestDijkstraAlgorithm();
//                               LinkedList<Vertex> patht=tj3.testExcute(edges5,n,edges5.length,source,destination);  
//                               if(patht.size()>max){
//                                   max=patht.size();
//                                   pos=o;
//                                   path3=new int[patht.size()];
//                                   h=0;
//		for (Vertex vertex : patht) {
//			
//                        path3[h]=Integer.valueOf(vertex.getName());
//                        h++;
//		}
//                               }
//                                        }
//                                        if(pos!=-1){
//                                            int [] edge=similarPaths.get(pos);
//                                            similarPaths=new ArrayList<int[]>();
//                                            similarPaths.add(edge);
//                                            lastpathCount=path3.length;
//                                            int [][] edges6=new int[edges4.length+1][];
//                                        int v=0;
//                                            for(;v<edges4.length;v++){
//                                                edges6[v]=new int[2];
//                                                edges6[v][0]=edges4[v][0];
//                                                edges6[v][1]=edges4[v][1];
//                                            }
//                                            edges6[v]=edge;
//                                            current++;
//                                            func3(edges6,n,edges6.length,source,destination,path3,current);
//                                        }
//                                        
//                                            
//                                    }
//                                         
//                                    }
                                    int[] edge = new int[2];
                                    edge[0]=path3[current];
                                    edge[1]=path3[current+1];
                                    similarPaths.add(edge);
                                    int random3=path3.length;    //set path length to new path's size
                                    if(maxpathlength<random3){  //that is if maximum path length has been attained
                    maxpathlength=random3;          //set maximumpathlength variable to current path length
                    System.out.println(maxpathlength);  //used for debugging-to better know how much of the processing has been done so far
//                    if(maxpathlength<n-2){
                    finalpaths=new ArrayList<int[]>();  //reinitialize the final paths storing list as we have got a better final path
                    fedges=new ArrayList<int[][]>();    //reinitialize the final edges variable as well
//                    }
                    int [][] ed = new int[edges4.length][];
                    for(j=0;j<edges4.length;j++) {
                        ed[j]=new int[2];
                        ed[j][0]=edges4[j][0];
                        ed[j][1]=edges4[j][1];
                    }
                    fedges.add(ed);                 //add current edges to final edges
                    //Now set a temppath integer array equal to path
                              
                    int[] temppath=new int[path3.length];
                    for (j=0;j<path3.length;j++) {
			
                        temppath[j]=path3[j];
                        
		}
                            finalpaths.add(temppath);   //add temppath to finalpaths List
                                    }
                                    else if(maxpathlength==random3)   //That is if we have found another path that is candidate for adding to finalpaths and fedges Lists
                                    {
                                        //Initialize finalpaths and fedges if they are null
//                                        if(finalpaths==null)
//                                        {
//                                            finalpaths=new ArrayList<int[]>();
//                                        }
//                                        if(fedges==null)
//                                        {
//                                            fedges=new ArrayList<int[][]>();
//                                        }
                                        int [][] ed = new int[edges4.length][];
                    for(j=0;j<edges4.length;j++) {
                        ed[j]=new int[2];
                        ed[j][0]=edges4[j][0];
                        ed[j][1]=edges4[j][1];
                    }
                    fedges.add(ed);   //add current edges to fedges List
                    //Now set a temppath integer array equal to path
                                       int[] temppath=new int[path3.length];
                    for (j=0;j<path3.length;j++) {
			
                        temppath[j]=path3[j];
                        
		}
                            finalpaths.add(temppath); //add temppath to finalpaths List
                                    //System.out.println(maxpathlength);
                                    }
                                    //Now proceed to set variables for next iteration:
                                         //main edges variable is updated to be equal to current edges variable
                                    
                                   //Now set path2 variable to store contents of path array
                                    
                                    
                                         //Store the new path2 variable's length in random2
//List<int[]> al2=new ArrayList<int[]>();
////System.out.println("Random2="+random2+"Edges4.length="+edges4.length);
//               for(j=0;j<edges4.length;j++)
//               {
//                    boolean toadd=true;
////                   for(int k=0;k<g2.bfspaths.size();k++)
////                       if(k!=g)
////                       {
////                          
////                           if(edges4[j][0]==(g2.bfspaths.get(k).get(current)+1) && edges4[j][1]==(g2.bfspaths.get(k).get(current+1)+1) || edges4[j][1]==(g2.bfspaths.get(k).get(current)+1) && edges4[j][0]==(g2.bfspaths.get(k).get(current+1)+1) )
////                           {
////                               toadd=false;
////                               //System.out.println("Deleting"+edges4[j][0]+"-"+edges4[j][1]);
//////                               System.out.println("YIPEEEEEEEEEEEEEE!!");
//////                               break;
////                           }
////                       }
////                   
////                   if(edges4[j][0]==path2[current] && edges4[j][1]==path2[current+1] || edges4[j][1]==path2[current] && edges4[j][0]==path2[current+1])
////                   {
////                       toadd=false;
////                        
////                   }
//                   if(toadd)
//                       al2.add(edges4[j]);
//               }
                

               int m3=edges5.length;//=al2.size();
               //System.out.println("m3="+m3+"current="+current);
                                    func3(edges5,n,m3,source,destination,path3,current);
                                    current= newcurrent;
//                                       return;
                                    
//                                    current++;
//                                
//                                todo=true;
                                }
//                                else if(path3.length==0){
//                                    if(similarPaths.size()>0){
//                                        int max=path2.length;
//                                        int pos=-1;
//                                        for(int o=0;o<similarPaths.size();o++)
//                                        {
//                                            int[][] edges5=new int[edges4.length+1][];
//                                            int v=0;
//                                            for(;v<edges4.length;v++){
//                                                edges5[v]=new int[2];
//                                                edges5[v][0]=edges4[v][0];
//                                                edges5[v][1]=edges4[v][1];
//                                            }
//                                            edges5[v]=similarPaths.get(o);
//                                            TestDijkstraAlgorithm tj3=new TestDijkstraAlgorithm();
//                               LinkedList<Vertex> patht=tj3.testExcute(edges5,n,edges5.length,source,destination);  
//                               if(patht.size()>max){
//                                   max=patht.size();
//                                   pos=o;
//                                   path3=new int[patht.size()];
//                                   h=0;
//		for (Vertex vertex : patht) {
//			
//                        path3[h]=Integer.valueOf(vertex.getName());
//                        h++;
//		}
//                               }
//                                        }
//                                        if(pos!=-1){
//                                            int [] edge=similarPaths.get(pos);
//                                            similarPaths=new ArrayList<int[]>();
//                                            similarPaths.add(edge);
//                                            lastpathCount=path3.length;
//                                            int [][] edges6=new int[edges4.length+1][];
//                                        int v=0;
//                                            for(;v<edges4.length;v++){
//                                                edges6[v]=new int[2];
//                                                edges6[v][0]=edges4[v][0];
//                                                edges6[v][1]=edges4[v][1];
//                                            }
//                                            edges6[v]=edge;
//                                            current++;
//                                            func3(edges6,n,edges6.length,source,destination,path3,current);
//                                        }
//                                        
//                                            
//                                    }
//                                }
                                    //System.out.println("endg="+g);
                                    
//                                }
                              // System.out.println("End of loop");
//                               todo=false;
                           }
//                               edges2=(int[][])fedges.get(0);
                               return; 
                           }
                           else {
                               currento++;
                               current=currento;
                               todo=true;
                           }
                                
                    
                           
               
                       
                       
//                   current++;
//                                
//                                todo=true;
               }
                
                
               
               
           
               
          //  System.out.println("End While");
       }
   }
    int[] answer;   //this variable stores the final Hamiltonian Cycle
    int[][] edges;   //This is the main graph's edges storing variable and is never changed
    boolean gotit=false;    //this is the main flag indicating whether we have found the Hamiltonian Cycle or not
    int n,m;      //n represents the number of vertices and m represents the number of edges in the main graph, these are also never changed

	
    /**
     * Creates new form MainJFrame
     */
    public MainJFrame() {
        initComponents();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jButton1.setText("Get Input File");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Get Hamiltonian Cycle");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("Verify");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(130, 130, 130)
                        .addComponent(jButton1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(53, 53, 53)
                        .addComponent(jButton2))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 633, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(20, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jButton3)
                .addGap(279, 279, 279))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jButton1)
                .addGap(10, 10, 10)
                .addComponent(jButton3)
                .addGap(74, 74, 74)
                .addComponent(jButton2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jTextField1, javax.swing.GroupLayout.DEFAULT_SIZE, 251, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
JFileChooser f=new JFileChooser();       //This is used to invoke a file selector dialog
f.setCurrentDirectory(new File("./HP Project/graph19"));
jButton2.setEnabled(false);
f.showOpenDialog(f);            //Show the file selector dialog
File file=f.getSelectedFile();  //get the selected file
m=0;                        //initialize m and n to 0-they are incremented as file is read
n=0;
int i=0;            //iteration variable
List<int[]> al=new ArrayList<int[]>();   //This is used to store the edges encountered one by one


        try
        {
        
		Scanner in = new Scanner(file);  //attach a read stream to current file
		//add all vertices
		while (in.hasNextLine()){   //while end of file is not encountered
                    i++;            //increment iteration
			 
                         String line2=in.nextLine(); //read next line from Scanner stream
			 if(i>6){                    //for CNF Formats from FHCP site, edges appear after 6th line so skip 6 lines  
                             if(line2.equals("-1")) //That is end of edges listing has happened as per FHCP format
                                 break;             //break the loop
			 String[] line3 = line2.split(" "); //Take split of string read
			 int k=0;
                         int l;
                         int[] edge = new int[2];       //Temporary variable to store current edge being read
                         for(l=0;l<line3.length;l++)    //read edge from splitted line below
                         {
                         if(!(line3[l].equals("") || line3[l].equals("\n")))
                         {
                             edge[k]=Integer.parseInt(line3[l]);
                             k++;
                         }
                         }
                         al.add(edge);          //add current edge to variable al
			if (edge[0]>n)          //update n below
                                n=edge[0];
                        if (edge[1]>n)
                                n=edge[1];
                           m++;      //update m here
				 
                         }
                         
                }
        }
                catch(FileNotFoundException ex)
                        {}
        //Next we remove unwanted and duplicate edges below
         for(i=0;i<m;i++)
         {
             for(int j=i+1;j<m;j++)
             {
                 if(al.get(i)[0]==al.get(j)[1] && al.get(i)[1]==al.get(j)[0] || al.get(i)[0]==al.get(j)[0] && al.get(i)[1]==al.get(j)[1])  //That is 2nd edge is duplicate of 1st edge
                 {
                     al.remove(j);
                     j--;
                     m--;
                 }
             }
         }
         System.out.println("m="+m);
         jButton2.setEnabled(true);
         //Now populate the edges variable array from al
         edges=new int[m][];
         for(i=0;i<m;i++)
         {
             edges[i]=new int[2];
             edges[i][0]=al.get(i)[0];
             edges[i][1]=al.get(i)[1];
         }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
//        String s="1,153,162,92,47,159,111,125,99,62,60,37,123,117,136,102,39,15,124,33,58,35,23,103,158,147,16,169,167,67,131,19,85,142,148,11,20,140,14,36,7,116,126,133,17,77,50,73,129,134,45,5,75,96,42,82,149,121,157,22,144,154,94,34,161,95,38,108,156,59,130,41,132,3,43,128,146,141,150,72,44,83,165,71,29,63,26,28,68,25,122,86,139,110,88,13,87,70,120,65,55,164,114,8,168,160,30,106,46,90,69,151,101,56,31,21,48,49,84,9,76,57,127,118,143,138,100,97,52,54,12,74,24,32,78,115,113,166,135,91,6,152,109,93,10,89,155,137,104,66,119,105,81,170,80,64,163,98,61,18,79,112,51,27,40,4,2,145,53,107";
//        
//        String[] a=s.split(",");
//        int[] answer=new int[a.length];
//        
//        if(answer.length!=n){
//        System.out.println("Lesser or greater answer length");
//        }
//        for(int i=0;i<answer.length;i++)
//            answer[i]=Integer.parseInt(a[i].toString());
//        for(int j=0;j<answer.length-1;j++){
//            boolean valid=false;
//            for(int i=0;i<m;i++){
//                if(edges[i][0]==answer[j] && edges[i][1]==answer[j+1] || edges[i][1]==answer[j] && edges[i][0]==answer[j+1])
//                {
//                    valid=true;
//                    break;
//                }
//             }
//            if(!valid){
//                System.out.println("INVALID"+answer[j]+" to "+answer[j+1]);
//            }
//        }
        
        for(int i=0;i<m;i++)   //for all edges do:
            if(!gotit)        //That is if we have still not found the Hamiltonian Cycle:
            {
                System.out.println("For edge: "+(i+1));  //for debugging only-to know how many edges are remaining
                func1(i);       //pass current edge to func1() function
            }
//        func5();
        if(!gotit)  //That is after all the iterations we have still not found the Hamiltonian Cycle
    jTextField1.setText("Not able to find Hamiltonian Cycle.");   //Print failure to find Hamiltonian Cycle
    
  
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
int i,j,k,l;
//uncomment below to check answer from answers folder if required, below is for graph12.hcp
//answer = new int[132];
//List<Integer> list = new ArrayList<>();
//Collections.addAll(list, 1,47,85,23,43,3,34,92,60,66,50,120,77,130,51,124,102,108,46,126,25,67,65,131,107,72,21,104,91,61,121,122,11,4,90,59,6,106,62,99,83,31,19,30,101,132,64,76,40,78,115,96,56,103,82,20,98,129,24,35,109,114,123,113,7,53,100,14,86,127,94,33,5,37,15,88,69,39,116,16,81,97,63,32,93,71,41,74,49,27,128,13,45,55,36,48,70,42,12,112,118,110,52,87,84,117,73,17,22,2,79,111,26,38,18,8,9,29,54,105,44,10,95,125,57,58,80,68,28,89,75,119);
//for(i=0;i<list.size();i++) {
//    answer[i]=list.get(i);
//}
int[] path=answer;
for(i=0;i<n;i++)
{
    for(j=i+1;j<n;j++)
    {
        if(path[i]==path[j])
        {
            System.out.println("Error1 of duplicate vertices");
        }
    }
}
boolean flag=false;
for(i=0;i<m;i++)
{
    if(edges[i][0]==path[0] && edges[i][1]==path[n-1] || edges[i][1]==path[0] && edges[i][0]==path[n-1])
    {
        flag=true;
        break;
    }
}
if(!flag)
    System.out.println("Error2 of unconnected start and finish");
for(i=0;i<n-1;i++)
{
    flag=false;
    for(j=0;j<m;j++)
    {
    if(edges[j][0]==path[i] && edges[j][1]==path[i+1] || edges[j][1]==path[i] && edges[j][0]==path[i+1])
    {
        flag=true;
        break;
    }
    }
    if(!flag)
        System.out.println("Error3 of no such edge of :"+path[i]+" to "+path[i+1]);
   
}
 System.out.println("Done!");
    }//GEN-LAST:event_jButton3ActionPerformed

class MyThread implements Runnable {
     List<Integer> path;
     LinkedList<Integer> adj[];
   public MyThread(List<Integer> path2,LinkedList<Integer> adj2[]) {
       path=path2;
       adj=adj2;
   }

   public void run() {
       
//       func1(path,adj);
   }
   }
public List<Integer> bfs(List<List<Integer>> grapht,int start,int end)
{
    List<List<Integer>> queue=new ArrayList<List<Integer>>();
    List<Integer> temp= new ArrayList<Integer>();
    temp.add(start);
    queue.add(temp);
    List<Integer> visited=new ArrayList<Integer>();
    while(queue.size()>0)
    {
        List<Integer> path=queue.get(0);
        queue.remove(0);
        int vertex=path.get(path.size()-1);
    if (vertex==end)
    {
        return path;
    }
    else if(!(visited.contains(vertex)))
    {
        for (int current_neighbour : grapht.get(vertex))
        {
            List<Integer> new_path=new ArrayList<Integer>();
            new_path.addAll(path);
            new_path.add(current_neighbour);
            queue.add(new_path);
        }
        visited.add(vertex);
    }
    }
    return null;
}
public List<List<Integer>> dfs3(int[][] edges2, int n, int from, List<Integer> path, List<Integer> seen) {
    List<List<Integer>> allpaths = new ArrayList<List<Integer>>();
    if(seen==null) {
        seen = new ArrayList<Integer>();
        
    }
    if(path==null) {
        path = new ArrayList<Integer>();
        path.add(from);
    }
    seen.add(from);
    allpaths.add(path);
    for(int i=0;i<edges2.length;i++) {
        if(edges2[i][0]==from || edges2[i][1]==from) {
            int x;
            if(edges2[i][0]==from) x = edges2[i][1];
            else
                x=edges2[i][0];
            if(!seen.contains(x)) {
                List<Integer> s = new ArrayList<Integer>(seen);
                s.add(x);
                List<Integer> p = new ArrayList<Integer>(path);
                p.add(x);
                List<List<Integer>> ap = dfs3(edges2,n,from,p,s);
                allpaths.addAll(ap);
            }
        }
    }
    return allpaths;
}
public List<Integer> dfs2(int[][] edges2,int n,int from) {
    List<Integer> path=new ArrayList<Integer>();
    path.add(from);
    boolean added=false;
    do{
        added=false;
        for(int i=0;i<edges2.length;i++) {
            int x=path.get(path.size()-1);
             if(edges2[i][0]==x && !path.contains(edges2[i][1]) || edges2[i][1]==x && !path.contains(edges2[i][0])) {
                 if(edges2[i][0]==x)
                     path.add(edges2[i][1]);
                 else
                     path.add(edges2[i][0]);
                 added=true;
                 break;
             }
}
    }while(added);
    
    return path;
}
   public List<List<Integer>> dfs(List<List<Integer>> G,int v,List<Integer> seen,List<Integer> path)
   {
       
       if(seen==null)
           seen=new ArrayList<Integer>();
       if(path==null)
       {
           path=new ArrayList<Integer>();
           path.add(v);
       }
       seen.add(v);
       List<List<Integer>> paths=new ArrayList<List<Integer>>();
       for (int t : G.get(v))
               {
                   if(!(seen.contains(t)))
                   {
                       List<Integer> t_path=new ArrayList<Integer>();
                       t_path.addAll(path);
                       t_path.add(t);
                       paths.add(t_path);
//                       List<Integer> seen2=new ArrayList<Integer>();
//                       for(int o=0;o<seen.size();o++)
//                       {
//                           seen2.add(seen.get(o));
//                       }
//                       List<List<Integer>> paths2=dfs(G,t,seen2,t_path);
                       List<List<Integer>> paths2=dfs(G,t,seen,t_path);
                       paths.addAll(paths2);
                   }
               }
       return paths;
   }
    void func1(int f1)           //This function is a small utility to remove current edge of the graph and pass it on to main trimming function that is func2()
    {
             int l; 
       
         
         int m2;
         int[][] edges2;
         //Set source and destination to current edge's start and last
             int source;
         int destination;
             source=edges[f1][0];
             destination=edges[f1][1];
            
         
                                
                     
                 
             
             
                
         //Set the new edges length and new edges variable now               
                m2=m-1;
                 edges2=new int[m2][];
                 int l1=0;
                  for(int k=0;k<m;k++)
                      if(k!=f1)
                      {
                          edges2[l1]=new int[2];
                         edges2[l1][0]=edges[k][0];
                         edges2[l1][1]=edges[k][1];
                         l1++;
                      }
                
         
         
        
         
         maxpathlength=0; //Set maxpath length = 0 for all edges' iterations. This is necessary as otherwise finalpaths and fedges won't be populated on each iteration for edges
         func3(edges2,n,m2,source,destination,null,0); //Invoke main trimming function of func2()
         
        
        if(gotit) //That is we have found Hamiltonian Cycle in trimming function itself
          {
            System.out.println("FOUND!!");
              jTextField1.setText("Hamiltonian Cycle found : ");  //Print found Hamiltonian Cycle!
             String str="";  //Populate the answer in string
              for(int i=0;i<n;i++)
                  str+=String.valueOf(answer[i])+",";
             str+=String.valueOf(answer[0]);
//    Below is for writing the output to a file          
//try{
//              FileOutputStream f=new FileOutputStream("D:\\Answer.txt"); // Manipulate filename here for different files
//              
//                                byte[] Bytes=str.getBytes();
//              f.write(Bytes);
//              f.close();
//              System.out.println("Wrote the output file!");
//              }
//              catch(Exception ex)
//              {
//                  System.out.println("Exception:"+ex.getMessage());
//              }
              jTextField1.setText(jTextField1.getText()+str); //Write the output Cycle to main textbox
          }
        else
        {
            for(int i=0;i<fedges.size();i++)
            {
                int[][] finaledges=(int[][])fedges.get(i);
                int[][] finale = new int[finaledges.length+1][];
                int[] ed = new int[2];
                ed[0]=source;
                ed[1]=destination;
                for(int j=0;j<finaledges.length;j++) {
                    finale[j]=finaledges[j];
                }
                finale[finale.length-1]=ed;
                List<List<Integer>> G=new ArrayList<List<Integer>>();
                for(int j=0;j<n;j++)
                {
                    List<Integer> temp=new ArrayList<Integer>();
                    G.add(temp);
                }
                for(int j=0;j<finale.length;j++)
                {
                    int from=finale[j][0];
                    int to=finale[j][1];
                    from--;
                    to--;
                    G.get(from).add(to);
                    G.get(to).add(from);
                }
//                  List<List<Integer>> dfspaths = dfs3(finale,n,source,null,null);
//                List<List<Integer>> dfspaths=new ArrayList<List<Integer>>();
//                List<Integer> pd=dfs2(finale,n,source);
//                
//                dfspaths.add(pd);
                List<List<Integer>> dfspaths=dfs(G,source-1,null,null);
                int max_len=0;
                for(int j=0;j<dfspaths.size();j++)
                    if(dfspaths.get(j).size()>max_len)
                        max_len=dfspaths.get(j).size();
                System.out.println("MAXLENGTH OF DFS PATH="+max_len);
                if(max_len==n)
                {
                String str="";
                for(int j=0;j<dfspaths.size();j++)
                    if(dfspaths.get(j).size()==max_len)
                    {
//                        int y=dfspaths.get(j).get(dfspaths.get(j).size()-1);
//                        List<Integer> list = G.get(source-1);
//                        if(!list.contains(y))
//                            continue;
                        answer=new int[n];
                        for(int k=0;k<dfspaths.get(j).size();k++)
                        {
                            int num=dfspaths.get(j).get(k);
                            answer[k]=num+1;
                            str+=String.valueOf(num+1)+",";
                        }
                        jTextField1.setText(str);
                        gotit=true;
                        return;
                    }
                
                
                }
            }
        }





//        else      //That is trimming function exited but was not able to find the cycle
//        {
//            
//            for(int i=0;i<fedges.size();i++)   //for all fedges and finalpaths do:
//            {
//                int[][] finaledges=(int[][])(fedges.get(i)); //take the current edges from fedges list
//                Graph g = new Graph(n);   //Initiate a graph of n vertices for doing DFS
//                for(int i1=0;i1<finaledges.length;i1++) //next add edges below in above graph      
//                {
//                    //Since we consider undireced graphs only so we add both from to to and to to from edges
//                    g.addEdge(finaledges[i1][0], finaledges[i1][1]);      
//                     g.addEdge(finaledges[i1][1], finaledges[i1][0]);
//                    
//                }
//                dfs=new ArrayList<Integer>();   //Initialize the DFS variable to empty
//                try{
//                    Vector<Boolean> visited = new Vector<Boolean>(n); 
//            for (int i2 = 0; i2 < n; i2++) 
//                visited.add(false);
//                g.DFS2(((int[])(finalpaths.get(i)))[0]-1,visited);  //Run DFS with variable as 1st element in finalpaths list's current path
//                }
//                catch(Exception ex)
//                {
//                    continue;
//                }
//				if(dfs.size()==n) //That is this is the LONGEST PATH!
//                for(int i1=0;i1<m;i1++)        //for all edges in the ORIGINAL GRAPH:
//                {
//                    //Check if there exists an edge from dfs path 1st and last vertex
//                    if(edges[i1][0]==((int[])(finalpaths.get(i)))[0] && edges[i1][1]==(int)(dfs.get(dfs.size()-1)) || edges[i1][1]==((int[])(finalpaths.get(i)))[0] && edges[i1][0]==(int)(dfs.get(dfs.size()-1)))  //That is such an edge exists!
//                            {
//                                gotit=true;            //We have found the Hamiltonian Cycle so need to set the global flag
//                                System.out.println("FOUND!!!");
//                               // jTextField1.setText("Found the Hamiltonian cycle : ");
//                                //Populate the answer in array of string
//                                StringBuilder str=new StringBuilder();
//                                for (int j=0;j<dfs.size();j++)
//                                    str.append(String.valueOf(dfs.get(j))+",");
//                                str.append(String.valueOf(dfs.get(0)));
//                                jTextField1.setText(jTextField1.getText()+str); //Print the output Hamiltonian Cycle to the main textbox
//                                //Below is for writing to file
////                                try{
////              FileOutputStream f=new FileOutputStream("D:\\Answer.txt");
////              FileWriter dos=new FileWriter("D:\\Answer.txt");
////              System.out.println("Writing to file now...");
////              f.write(str.toString().getBytes());
////              f.close();
////              System.out.println("Wrote the output file!");
////              }
////              catch(Exception ex)
////              {
////                  System.out.println("Exception:"+ex.getMessage());
////              }
//                                return;  //End the function
//                            }
//                }
//            }
//        }
           
                     
                 
         
  }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainJFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
