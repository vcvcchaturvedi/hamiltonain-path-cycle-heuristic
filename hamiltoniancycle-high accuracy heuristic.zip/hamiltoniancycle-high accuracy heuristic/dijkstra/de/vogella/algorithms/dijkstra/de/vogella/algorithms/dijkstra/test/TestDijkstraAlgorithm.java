package de.vogella.algorithms.dijkstra.de.vogella.algorithms.dijkstra.test;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;



import de.vogella.algorithms.dijkstra.de.vogella.algorithms.dijkstra.engine.DijkstraAlgorithm;
import de.vogella.algorithms.dijkstra.de.vogella.algorithms.dijkstra.model.Edge;
import de.vogella.algorithms.dijkstra.de.vogella.algorithms.dijkstra.model.Graph;
import de.vogella.algorithms.dijkstra.de.vogella.algorithms.dijkstra.model.Vertex;



public class TestDijkstraAlgorithm {

	private List<Vertex> nodes;
	private List<Edge> edges;

	
	public  LinkedList<Vertex> testExcute(int[][] edges1,int nov,int noedges,int source,int destination) {
		nodes = new ArrayList<Vertex>();
		edges = new ArrayList<Edge>();
                
                 int i;
		for (i = 0; i < nov; i++) {
                    
                       
                    
                   
			Vertex location = new Vertex(String.valueOf(i+1),String.valueOf(i+1));
			nodes.add(location);
                    
		}
               
                try{
                for(i=0;i<noedges;i++)
                {
                    //For undirected graph we have to add edge from both source to destination and destination to source
                    addLane("Edge_"+String.valueOf(i+1), edges1[i][0], edges1[i][1], 1);
                    addLane("Edge_"+String.valueOf(2*i+2), edges1[i][1], edges1[i][0], 1); 
                }
                }
                catch(Exception ex)
                {
                    System.out.println("Exception:"+i);
                }
		
		Graph graph = new Graph(nodes, edges);
		DijkstraAlgorithm dijkstra = new DijkstraAlgorithm(graph);
                Vertex sourceLocNo,destLocNo;
                sourceLocNo=null;
            destLocNo=null;
            
            for(i=0;i<nodes.size();i++)
            {
                if(source==Integer.parseInt(nodes.get(i).getId()))
                    sourceLocNo=nodes.get(i);
                if(destination==Integer.parseInt(nodes.get(i).getId()))
                    destLocNo=nodes.get(i);
            }
		dijkstra.execute(sourceLocNo);  //Initiate Dijkstra's algorithm with source
		LinkedList<Vertex> path = dijkstra.getPath(destLocNo); //Run above ALgorithm with destination as destLocNo
		
		
		
                return path;
               
	}

	private void addLane(String laneId, int sourceLocNo, int destLocNo,
			int duration) {
            if(sourceLocNo==-1 || destLocNo==-1)
                System.out.print("HI");
            Vertex source,destination;
            source=null;
            destination=null;
            int i;
            for(i=0;i<nodes.size();i++)
            {
                if(sourceLocNo==Integer.parseInt(nodes.get(i).getId()))
                    source=nodes.get(i);
                if(destLocNo==Integer.parseInt(nodes.get(i).getId()))
                    destination=nodes.get(i);
            }
            if(source==null || destination==null)
                System.out.print("NULL!");
		Edge lane = new Edge(laneId,source, destination, duration );
		edges.add(lane);
	}
}
